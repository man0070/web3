export const MAX_TIMER_IN_MINUTES = 5;
export const SCROLL_AMOUNT = 400;
export const PRESICION_LENGTH = 6;

export const ACCESS_TOKEN_LOCAL_STORAGE='access_token';
